$(document).ready(function()
{	
	currentScore = new score();
	
	$("#roll").click(function()
	{
		game = new CrapsGame(currentScore);
	});
});

var Dice = function(die1, die2)
{
	this.die1 = $(die1);
	this.die2 = $(die2);
	this.value1 = 0;
	this.value2 = 0;
	this.value = this.value1 + this.value2;
	this.imgArray = ["blank", "images/dice1.png", "images/dice2.png", "images/dice3.png", 
						"images/dice4.png", "images/dice5.png", "images/dice6.png"];
}

Dice.prototype.roll = function()
{
	this.value1 = this.getRandom();
	this.value2 = this.getRandom();
	this.value = this.value1 + this.value2;
	this.update();
}

// update the dice images
Dice.prototype.update = function()
{
	(this.die1).attr("src", this.imgArray[this.value1]);
	(this.die2).attr("src", this.imgArray[this.value2]);	
}

Dice.prototype.getRandom = function()
{
	var ranNum = Math.floor((Math.random()*6));
	return ranNum + 1;  // so as to avoid returning 0
}

var CrapsGame = function(theScore)
{	
	if (theScore.wins != 0 || theScore.losses != 0)
		$("#endImage").toggle();
	
	$("#roll").unbind('click');
	that = this;
	this.wins = 0;
	this.losses = 0;
	
	dice = new Dice("#die1", "#die2");  // create dice object and roll dice
	dice.roll();
	rollFirst = dice.value;  // save the original dice value;

	if (dice.value == 7 || dice.value == 11)
	{
		$("#update").html("You rolled a " + dice.value + ". You win!  Roll again to start a new game.");
		theScore.addWin();
		$("#roll").click(function() {game = new CrapsGame(currentScore);});
	}
	else if (dice.value == 2 || dice.value == 3 || dice.value == 12)
	{
		$("#update").html("You rolled a " + dice.value + ". You lose!  Roll again to start a new game.");
		theScore.addLoss();
		$("#roll").click(function() {game = new CrapsGame(currentScore);});
	}
	else if (dice.value == 4 || dice.value == 5 || dice.value == 6 || dice.value == 8 || dice.value == 9 || dice.value == 10)
	{	
		$("#update").html("You rolled a " + dice.value + ". Roll Again!");  // user rolls again
		$("#roll").click(function() 
		{
			dice.roll();
			if (dice.value == rollFirst)
			{
				$("#update").html("You rolled a " + dice.value + ". You win!  Roll again to start a new game.");
				theScore.addWin();
				$("#roll").unbind('click');
				$("#roll").click(function() {game = new CrapsGame(currentScore);});
			}
			else if (dice.value == 7)
			{
				$("#update").html("You rolled a " + dice.value + ". You lose!  Roll again to start a new game.");
				theScore.addLoss();
				$("#roll").unbind('click');
				$("#roll").click(function() {game = new CrapsGame(currentScore);});
			}
			else
			{
				$("#update").html("You rolled a " + dice.value + ". Roll Again!");
			}
		});
	}
}

var score = function()
{
	this.wins = 0;
	this.losses = 0;
}

score.prototype.addWin = function()
{
	$("#imgResult").attr('src', 'images/check.png');
	this.wins = this.wins + 1;
	$("#wins").html("Wins: " + this.wins);
	$("#endImage").fadeToggle(800);
}

score.prototype.addLoss = function()
{
	$("#imgResult").attr('src', 'images/x2.png');
	this.losses = this.losses + 1;
	$("#losses").html("Losses: " + this.losses);
	$("#endImage").fadeToggle(800);
}